package com.sketchbot.app

import android.content.Context
import android.graphics.Canvas
import android.os.SystemClock
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.graphics.Outline
import android.graphics.RadialGradient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max

/** اهتزاز خفيف وناعم عند اللمس */
object Haptic {
    private var vib: android.os.Vibrator? = null
    fun tap(ctx: Context) {
        try {
            val v = vib ?: (ctx.applicationContext.getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator).also { vib = it }
            if (android.os.Build.VERSION.SDK_INT >= 26) v.vibrate(android.os.VibrationEffect.createOneShot(9, 28))
            else @Suppress("DEPRECATION") v.vibrate(9)
        } catch (_: Throwable) {}
    }
}

/** مقبض تغيير الحجم (زاوية سفلية) */
class GripView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E5700F"); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.strokeWidth = w * 0.09f
        for (i in 1..3) {
            val o = w * (0.22f * i)
            c.drawLine(w - o, h - w * 0.1f, w - w * 0.1f, h - o, p)
        }
    }
}

/** الثيم الدافئ (كريمي + برتقالي + بني داكن) */
object Th {
    var dark = false
    var CREAM = 0; var CARD = 0; var LINE = 0; var BROWN = 0; var MUTED = 0; var TAN = 0
    var BTN = 0; var SOFT = 0; var PANELC = 0; var PLINE = 0; var TRACK = 0; var PBG = 0; var SWOFF = 0
    var G1 = 0; var G2 = 0; var GLINE = 0
    var NAV1 = 0; var NAV2 = 0
    val O1 = Color.parseColor("#FFA23A")
    val O2 = Color.parseColor("#E5470B")

    fun init(ctx: Context) {
        dark = ctx.getSharedPreferences("sb", Context.MODE_PRIVATE).getBoolean("dark", false)
        Tr.init(ctx)
        if (dark) {
            CREAM = Color.parseColor("#1C110B"); CARD = Color.parseColor("#2B1B12"); LINE = Color.parseColor("#47301F")
            BROWN = Color.parseColor("#FBEDE0"); MUTED = Color.parseColor("#CDA98C"); TAN = Color.parseColor("#9A7558")
            BTN = Color.parseColor("#36241A"); SOFT = Color.parseColor("#3D291D"); PANELC = Color.argb(0xF2, 0x2B, 0x1B, 0x12)
            PLINE = Color.parseColor("#6B4426"); TRACK = Color.parseColor("#4A3426"); PBG = Color.parseColor("#241812")
            SWOFF = Color.parseColor("#5A4435"); G1 = Color.parseColor("#44291A"); G2 = Color.parseColor("#2A1A11")
            GLINE = Color.parseColor("#8A5428"); NAV1 = Color.parseColor("#24130A"); NAV2 = Color.parseColor("#140A04")
        } else {
            CREAM = Color.parseColor("#FCF3EA"); CARD = Color.parseColor("#FFF8F1"); LINE = Color.parseColor("#F0DFCD")
            BROWN = Color.parseColor("#3A1A0C"); MUTED = Color.parseColor("#8C5E42"); TAN = Color.parseColor("#B98D6B")
            BTN = Color.parseColor("#FFFBF6"); SOFT = Color.parseColor("#F7E7D6"); PANELC = Color.argb(0xF4, 255, 247, 238)
            PLINE = Color.parseColor("#F6D7B0"); TRACK = Color.parseColor("#EADBCB"); PBG = Color.parseColor("#FFFDFB")
            SWOFF = Color.parseColor("#E4D3C2"); G1 = Color.parseColor("#FFFFFF"); G2 = Color.parseColor("#FFEBD8")
            GLINE = Color.parseColor("#F5B77A"); NAV1 = Color.parseColor("#3E1F0F"); NAV2 = Color.parseColor("#2A1309")
        }
    }

    init { init0() }
    private fun init0() {
        // قيم افتراضية قبل استدعاء init(ctx)
        CREAM = Color.parseColor("#FCF3EA"); CARD = Color.parseColor("#FFF8F1"); LINE = Color.parseColor("#F0DFCD")
        BROWN = Color.parseColor("#3A1A0C"); MUTED = Color.parseColor("#8C5E42"); TAN = Color.parseColor("#B98D6B")
        BTN = Color.parseColor("#FFFBF6"); SOFT = Color.parseColor("#F7E7D6"); PANELC = Color.argb(0xF4, 255, 247, 238)
        PLINE = Color.parseColor("#F6D7B0"); TRACK = Color.parseColor("#EADBCB"); PBG = Color.parseColor("#FFFDFB")
        SWOFF = Color.parseColor("#E4D3C2"); G1 = Color.parseColor("#FFFFFF"); G2 = Color.parseColor("#FFEBD8")
        GLINE = Color.parseColor("#F5B77A"); NAV1 = Color.parseColor("#3E1F0F"); NAV2 = Color.parseColor("#2A1309")
    }

    fun dp(ctx: Context, v: Float): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun pressable(v: View) {
        v.isClickable = true
        v.setOnTouchListener { x, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> x.animate().cancel().also {
                    Haptic.tap(x.context)
                    x.animate().scaleX(0.93f).scaleY(0.93f).setDuration(110).setInterpolator(DecelerateInterpolator()).start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    x.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(2.6f)).start()
            }
            false
        }
    }

    fun squareBtn(ctx: Context, icon: Int, ink: Int, sizeDp: Float = 46f, orange: Boolean = false, outlined: Boolean = false): FrameLayout {
        val d = ctx.resources.displayMetrics.density
        val f = FrameLayout(ctx)
        f.background = WarmDrawable(if (orange) WarmDrawable.ORANGE else if (outlined) WarmDrawable.OUTLINE else WarmDrawable.BTN, 16f, d)
        val s = (sizeDp * 0.48f * d).toInt()
        f.addView(IconView(ctx, icon, 0, 0, if (orange) Color.WHITE else ink), FrameLayout.LayoutParams(s, s, Gravity.CENTER))
        pressable(f)
        return f
    }

    fun text(ctx: Context, s: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(ctx).apply {
        text = Tr.t(s)
        setPadding(0, 0, (2 * ctx.resources.displayMetrics.density).toInt(), 0)
        includeFontPadding = true
        textSize = size
        setTextColor(color)
        typeface = android.graphics.Typeface.create("sans-serif-medium", if (bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
    }
}

/** خلفيات الثيم الدافئ */
class WarmDrawable(
    private val mode: Int,
    private val rDp: Float,
    private val d: Float,
    private val topOnly: Boolean = false
) : Drawable() {
    companion object {
        const val CARD = 0
        const val ORANGE = 1
        const val BTN = 2
        const val NAV = 3
        const val ACTIVE = 4
        const val SOFT = 5
        const val OUTLINE = 6
        const val PANEL = 7
        const val GLASS = 8
    }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = max(1f, d) }
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private var hasLine = true
    private var hasGloss = false
    private var hasGlow = false
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spec = Paint(Paint.ANTI_ALIAS_FLAG)
    private val streak = Path()

    override fun onBoundsChange(b: Rect) {
        rect.set(b.left + 0.5f * d, b.top + 0.5f * d, b.right - 0.5f * d, b.bottom - 0.5f * d)
        val top = rect.top
        val bot = rect.bottom
        when (mode) {
            CARD -> { fill.shader = null; fill.color = Th.CARD; line.color = Th.LINE }
            BTN -> { fill.shader = null; fill.color = Th.BTN; line.color = Th.LINE }
            SOFT -> { fill.shader = null; fill.color = Th.SOFT; hasLine = false }
            PANEL -> { fill.shader = null; fill.color = Th.PANELC; line.color = Th.PLINE; line.strokeWidth = 1.5f * d }
            OUTLINE -> { fill.shader = null; fill.color = Th.BTN; line.color = Th.O1; line.strokeWidth = 1.6f * d }
            ORANGE -> {
                fill.shader = LinearGradient(0f, top, 0f, bot, Th.O1, Th.O2, Shader.TileMode.CLAMP)
                line.color = Color.argb(0x70, 255, 205, 150)
                gloss.shader = LinearGradient(0f, top, 0f, top + (bot - top) * 0.55f, Color.argb(0x50, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
                hasGloss = true
            }
            NAV -> {
                fill.shader = LinearGradient(0f, top, 0f, bot, Th.NAV1, Th.NAV2, Shader.TileMode.CLAMP)
                hasLine = false
            }
            GLASS -> {
                fill.shader = LinearGradient(0f, top, 0f, bot, Th.G1, Th.G2, Shader.TileMode.CLAMP)
                line.shader = LinearGradient(0f, top, 0f, bot, Th.GLINE, Th.LINE, Shader.TileMode.CLAMP)
                line.strokeWidth = 1.6f * d
                val hh = (bot - top) * 0.46f
                val a1 = if (Th.dark) 0x30 else 0x95
                gloss.shader = LinearGradient(0f, top, 0f, top + hh, Color.argb(a1, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
                hasGloss = true
                glow.shader = RadialGradient(rect.right, rect.bottom, (rect.width() * 0.75f).coerceAtLeast(1f),
                    Color.argb(if (Th.dark) 0x38 else 0x30, 255, 138, 31), Color.argb(0, 255, 138, 31), Shader.TileMode.CLAMP)
                hasGlow = true
                streak.reset()
                val sw = rect.width()
                streak.moveTo(rect.left + sw * 0.08f, top)
                streak.lineTo(rect.left + sw * 0.26f, top)
                streak.lineTo(rect.left + sw * 0.10f, bot)
                streak.lineTo(rect.left - sw * 0.08f, bot)
                streak.close()
                spec.color = Color.argb(if (Th.dark) 0x10 else 0x28, 255, 255, 255)
            }
            ACTIVE -> {
                fill.shader = LinearGradient(0f, top, 0f, bot, Color.argb(0xC0, 150, 70, 20), Color.argb(0xA0, 90, 40, 12), Shader.TileMode.CLAMP)
                line.color = Color.argb(0xE0, 255, 138, 31)
                line.strokeWidth = 1.5f * d
            }
        }
        path.reset()
        val r = rDp * d
        if (topOnly) path.addRoundRect(rect, floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f), Path.Direction.CW)
        else path.addRoundRect(rect, r, r, Path.Direction.CW)
    }

    override fun draw(c: Canvas) {
        c.drawPath(path, fill)
        if (hasGlow) {
            c.save(); c.clipPath(path); c.drawRect(rect, glow)
            if (mode == GLASS) c.drawPath(streak, spec)
            c.restore()
        }
        if (hasGloss) c.drawPath(path, gloss)
        if (mode == GLASS) {
            // خط لمعان رفيع على الحافة العلوية الداخلية
            val hl = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = d
                color = Color.argb(if (Th.dark) 0x40 else 0xE0, 255, 255, 255)
            }
            c.save()
            c.clipRect(rect.left, rect.top, rect.right, rect.top + rect.height() * 0.3f)
            val inset = RectF(rect.left + 2.2f * d, rect.top + 2.2f * d, rect.right - 2.2f * d, rect.bottom - 2.2f * d)
            c.drawRoundRect(inset, rDp * d - 2f * d, rDp * d - 2f * d, hl)
            c.restore()
        }
        if (hasLine) c.drawPath(path, line)
    }

    override fun getOutline(o: Outline) {
        if (mode == GLASS) { o.setRoundRect(bounds, rDp * d); o.alpha = 0.55f } else o.setEmpty()
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** مفتاح تبديل برتقالي بزرّ أبيض (حركة سلسة) */
class WarmSwitch(ctx: Context) : View(ctx) {
    private var pos = 1f
    var checked: Boolean = true
        set(v) {
            field = v
            animTo(if (v) 1f else 0f)
        }
    var onChange: ((Boolean) -> Unit)? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val knob = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        setShadowLayer(4f * ctx.resources.displayMetrics.density, 0f, 2f, Color.argb(0x45, 0, 0, 0))
    }
    private val rect = RectF()
    private var va: ValueAnimator? = null

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        isClickable = true
        setOnClickListener { checked = !checked; onChange?.invoke(checked) }
        Th.pressable(this)
    }

    private fun animTo(t: Float) {
        va?.cancel()
        va = ValueAnimator.ofFloat(pos, t).apply {
            duration = 240
            interpolator = OvershootInterpolator(1.4f)
            addUpdateListener { pos = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(Th.dp(context, 54f), Th.dp(context, 32f))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        rect.set(0f, 0f, w, h)
        val k = pos.coerceIn(0f, 1f)
        track.shader = null
        track.color = ArgbEvaluator().evaluate(k, Th.SWOFF, Color.parseColor("#F5701D")) as Int
        c.drawRoundRect(rect, h / 2f, h / 2f, track)
        track.shader = LinearGradient(0f, 0f, w, 0f, Color.argb((255 * k).toInt(), 242, 107, 29), Color.argb((255 * k).toInt(), 255, 162, 58), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, h / 2f, h / 2f, track)
        val r = h / 2f - 3.5f * resources.displayMetrics.density
        val cx = h / 2f + (w - h) * pos
        c.drawCircle(cx, h / 2f, r, knob)
    }
}

/** عنصر شريط التنقّل السفلي (المؤشر البرتقالي المنزلق يُرسم في MainActivity) */
class NavItem(ctx: Context, icon: Int, caption: String) : LinearLayout(ctx) {
    private val ic = IconView(ctx, icon, 0, 0, Th.TAN)
    private val tv = TextView(ctx)
    private val d = ctx.resources.displayMetrics.density
    private var va: ValueAnimator? = null
    private var on = false

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        setPadding((8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
        val s = (26 * d).toInt()
        addView(ic, LayoutParams(s, s))
        tv.text = Tr.t(caption)
        tv.setPadding(0, 0, (2 * d).toInt(), 0)
        tv.textSize = 13f
        tv.gravity = Gravity.CENTER
        tv.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        addView(tv, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { topMargin = (3 * d).toInt() })
        paint(0f)
        isClickable = true
        // الضغط: الأيقونة فقط تنضغط (لا يتغير حجم العنصر كله حتى لا يختلف عن المؤشر البرتقالي)
        setOnTouchListener { _, e ->
            val rest = if (on) 1.16f else 1f
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    Haptic.tap(context)
                    ic.animate().cancel()
                    ic.animate().scaleX(rest * 0.82f).scaleY(rest * 0.82f).setDuration(100).setInterpolator(DecelerateInterpolator()).start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    ic.animate().cancel()
                    ic.animate().scaleX(rest).scaleY(rest).setDuration(300).setInterpolator(OvershootInterpolator(2.4f)).start()
                }
            }
            false
        }
    }

    private fun paint(k: Float) {
        val col = ArgbEvaluator().evaluate(k, Th.TAN, Color.WHITE) as Int
        ic.setInk(col)
        tv.setTextColor(col)
        ic.scaleX = 1f + 0.16f * k
        ic.scaleY = 1f + 0.16f * k
        ic.translationY = -2f * d * k
    }

    fun setActive(a: Boolean, animate: Boolean = true) {
        if (a == on && animate) return
        on = a
        va?.cancel()
        if (!animate) { paint(if (a) 1f else 0f); return }
        va = ValueAnimator.ofFloat(if (a) 0f else 1f, if (a) 1f else 0f).apply {
            duration = 300
            interpolator = DecelerateInterpolator()
            addUpdateListener { paint(it.animatedValue as Float) }
            start()
        }
    }
}

fun orangeThumb(ctx: Context): GradientDrawable {
    val d = ctx.resources.displayMetrics.density
    return GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.WHITE)
        setStroke((3 * d).toInt(), Color.parseColor("#F5701D"))
        setSize((26 * d).toInt(), (26 * d).toInt())
    }
}

/** حاوية أفقية قابلة للضغط بحركة ارتداد ناعمة */
open class DropLinear(ctx: Context) : LinearLayout(ctx) {
    var dropColor: Int = Color.parseColor("#FF8A1F")

    init {
        clipChildren = false
        clipToPadding = false
        isClickable = true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> animate().cancel().also {
                Haptic.tap(context)
                animate().scaleX(0.94f).scaleY(0.94f).setDuration(110).setInterpolator(DecelerateInterpolator()).start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(2.6f)).start()
        }
        return super.onTouchEvent(e)
    }
}

/** زر اللوحة العائمة: بلاطة زجاجية بقطرات ماء + نص */
class WaterButton(ctx: Context, icon: Int, caption: String, c1: Int, c2: Int, glyph: Int = 0) : DropLinear(ctx) {
    init {
        val d = ctx.resources.displayMetrics.density
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = WarmDrawable(WarmDrawable.BTN, 22f, d)
        setPadding((8 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
        dropColor = c2
        val s = (40 * d).toInt()
        addView(IconView(ctx, icon, c1, c2, glyph, true), LayoutParams(s, s))
        addView(Th.text(ctx, caption, 13.5f, Th.BROWN, true).apply {
            gravity = Gravity.CENTER
            maxLines = 1
        }, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
    }
}

/** عنوان بتدرّج بني ثم برتقالي */
class WarmGradientText(ctx: Context) : TextView(ctx) {
    override fun onDraw(c: Canvas) {
        val w = max(1f, width.toFloat())
        paint.shader = LinearGradient(
            0f, 0f, w, 0f,
            intArrayOf(Th.BROWN, Th.BROWN, Color.parseColor("#E5470B"), Color.parseColor("#F26B1D")),
            floatArrayOf(0f, 0.55f, 0.82f, 1f), Shader.TileMode.CLAMP
        )
        super.onDraw(c)
    }
}
